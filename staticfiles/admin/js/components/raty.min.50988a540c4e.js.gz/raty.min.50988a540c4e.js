/*!
 * Remark (http://getbootstrapadmin.com/remark)
 * Copyright 2016 amazingsurge
 * Licensed under the Themeforest Standard Licenses
 */
$.components.register("rating",{mode:"init",defaults:{targetKeep:!0,icon:"font",starType:"i",starOff:"icon md-star",starOn:"icon md-star orange-600",cancelOff:"icon md-minus-circle",cancelOn:"icon md-minus-circle orange-600",starHalf:"icon md-star-half orange-500"},init:function(context){if($.fn.raty){var defaults=$.components.getDefaults("rating");$('[data-plugin="rating"]',context).each(function(){var $this=$(this),options=$.extend(!0,{},defaults,$this.data());options.hints&&(options.hints=options.hints.split(",")),$this.raty(options)})}}});