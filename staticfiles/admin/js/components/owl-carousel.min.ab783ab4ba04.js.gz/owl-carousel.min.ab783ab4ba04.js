/*!
 * Remark (http://getbootstrapadmin.com/remark)
 * Copyright 2016 amazingsurge
 * Licensed under the Themeforest Standard Licenses
 */
$.components.register("owlCarousel",{mode:"default",defaults:{loop:!0,nav:!0,dots:!1,dotsClass:"owl-dots owl-dots-fall",responsive:{0:{items:1},600:{items:3}}}});