/*!
 * Remark (http://getbootstrapadmin.com/remark)
 * Copyright 2016 amazingsurge
 * Licensed under the Themeforest Standard Licenses
 */
$.components.register("taskList",{mode:"api",api:function(){$(document).on("change.site.task",'[data-role="task"]',function(){var $list=$(this),$checkbox=$list.find('[type="checkbox"]');$checkbox.is(":checked")?$list.addClass("task-done"):$list.removeClass("task-done")}),$('[data-role="task"]').trigger("change.site.task")}});