/*!
 * Remark (http://getbootstrapadmin.com/remark)
 * Copyright 2016 amazingsurge
 * Licensed under the Themeforest Standard Licenses
 */
$.components.register("TouchSpin",{mode:"default",defaults:{verticalupclass:"md-plus",verticaldownclass:"md-minus",buttondown_class:"btn btn-default",buttonup_class:"btn btn-default"}});